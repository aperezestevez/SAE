import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  {
    path: 'activitats/:dni',
    loadChildren: () => import('./pages/activitats/activitats.module').then( m => m.ActivitatsPageModule)
  },
  {
    path: 'activitats/:id/:dni',
    loadChildren: () => import('./pages/activitats-detail/activitats-detail.module').then( m => m.ActivitatsDetailPageModule)
  },
  {
    path: 'dades-personals/:dni',
    loadChildren: () => import('./pages/dades-personals/dades-personals.module').then( m => m.DadesPersonalsPageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./pages/login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'llista-inscrip-obertes',
    loadChildren: () => import('./pages/llista-inscrip-obertes/llista-inscrip-obertes.module').then( m => m.LlistaInscripObertesPageModule)
  },
  {
    path: 'matricula/:codiAct',
    loadChildren: () => import('./pages/matricula/matricula.module').then( m => m.MatriculaPageModule)
  },
  {
    path: 'config-app',
    loadChildren: () => import('./pages/config-app/config-app.module').then( m => m.ConfigAppPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
