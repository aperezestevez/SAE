import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-config-app',
  templateUrl: './config-app.page.html',
  styleUrls: ['./config-app.page.scss'],
})
export class ConfigAppPage implements OnInit {
  Dni: any;
  darkMode: boolean;
  constructor() { 
    //const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
    //this.darkMode = prefersDark.matches;


  }

  ngOnInit() {
    this.Dni = localStorage.getItem('loginDni')
    console.log('DM: '+ window.localStorage.getItem('darkmode'))
    if ( typeof(window.localStorage.getItem('darkmode'))!=='undefined' ) {
      var darkmodelocal:boolean
      darkmodelocal =(window.localStorage.getItem('darkmode')== 'true')

      this.darkMode= darkmodelocal
    }else{
      this.darkMode= false

    }
  }
  cambioModo(){
    // const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
    this.darkMode = !this.darkMode;
   

    window.localStorage.setItem('darkmode',String(this.darkMode))
    document.body.classList.toggle('dark', this.darkMode);
    console.log("DArkmode"+this.darkMode)

  }

}
