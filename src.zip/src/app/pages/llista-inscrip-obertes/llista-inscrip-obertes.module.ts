import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { LlistaInscripObertesPageRoutingModule } from './llista-inscrip-obertes-routing.module';

import { LlistaInscripObertesPage } from './llista-inscrip-obertes.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    LlistaInscripObertesPageRoutingModule
  ],
  declarations: [LlistaInscripObertesPage]
})
export class LlistaInscripObertesPageModule {}
