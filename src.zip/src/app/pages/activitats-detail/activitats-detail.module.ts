import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ActivitatsDetailPageRoutingModule } from './activitats-detail-routing.module';

import { ActivitatsDetailPage } from './activitats-detail.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ActivitatsDetailPageRoutingModule
  ],
  declarations: [ActivitatsDetailPage]
})
export class ActivitatsDetailPageModule {}
