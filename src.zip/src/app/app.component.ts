import { Component } from '@angular/core';

import { Platform,NavController } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Deeplinks } from '@ionic-native/deeplinks/ngx';
import { Router } from '@angular/router';
import { NgZone } from '@angular/core';
import { ActivitatsPage } from './pages/activitats/activitats.page';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {
  
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private deeplinks: Deeplinks,
    private router: Router,
    private zone: NgZone,
    protected navController: NavController
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
      this.checkDarkTheme();
      this.setupDeeplinks();

    });

  }
  checkDarkTheme() {
    //const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');

    if ( typeof(window.localStorage.getItem('darkmode'))!=='undefined' ) {
      var darkmode:boolean
      darkmode =(window.localStorage.getItem('darkmode')== 'true')

      document.body.classList.toggle( 'dark',  darkmode);
    }else{
      document.body.classList.toggle( 'dark',  false);
    }
  }
  setupDeeplinks() {
    console.log('Indeeplinks')
    this.deeplinks.route({ '/activitats/:dni': ActivitatsPage }).subscribe(
      match => {
        console.log('Successfully matched route', match);
 
        // Create our internal Router path by hand
        const internalPath = `/${match.$route}/${match.$args['dni']}`;
 
        // Run the navigation in the Angular zone
        this.zone.run(() => {
          this.router.navigateByUrl(internalPath);
        });
      },
      nomatch => {
        // nomatch.$link - the full link data
        console.error("Got a deeplink that didn't match", nomatch);
      }
    );
  }

};


