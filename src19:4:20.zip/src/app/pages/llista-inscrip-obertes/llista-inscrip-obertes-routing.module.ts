import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LlistaInscripObertesPage } from './llista-inscrip-obertes.page';

const routes: Routes = [
  {
    path: '',
    component: LlistaInscripObertesPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LlistaInscripObertesPageRoutingModule {}
