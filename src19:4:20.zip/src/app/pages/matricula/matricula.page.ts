import { Component, OnInit } from '@angular/core';
import { ActivatedRoute , Router} from '@angular/router';
import { ActivitatService } from 'src/app/services/activitat.service';
import * as xml2js from 'xml2js';
import { AlertController, Platform } from '@ionic/angular';
import { Calendar } from '@ionic-native/calendar/ngx';
import { resolve } from 'dns';

@Component({
  selector: 'app-matricula',
  templateUrl: './matricula.page.html',
  styleUrls: ['./matricula.page.scss'],
})
export class MatriculaPage implements OnInit {
  results:any;
  codiAct:any;
  matriculat:any;
  resultsAgrupats:any;
  nomActivitat:any;
  dni:any;
  calendars = [];
  matObertes:any;

  constructor(private router: Router , private activitatService: ActivitatService,private activatedRoute: ActivatedRoute,
    public alertController: AlertController, private calendar: Calendar, private platform: Platform) { 

      this.platform.ready().then(() => {
        this.calendar.requestReadWritePermission();
        this.calendar.hasWritePermission().then(permission =>{
          console.log("PERMISION: "+ permission)
              this.calendar.listCalendars().then(data => {
                this.calendars = data;
                  console.log('constructorCal'+data)
              })
              .catch(err => {console.log('errorCalConstru: '+ err)});

        });

        
      });
    }

  ngOnInit() {
    var d;
    var agrupa;
    this.dni=localStorage.getItem("loginDni")
    console.log("Dni: ", this.dni);
    this.codiAct = this.activatedRoute.snapshot.paramMap.get('codiAct');
    console.log("Codi: ", this.codiAct);

    this.activitatService.jaMatriculat(this.codiAct,localStorage.getItem("loginDni")).subscribe(dataMat =>{   
      console.log('datamat',dataMat)
      if (dataMat==='true'){
        this.matriculat=true;
        console.log('Matriculat',dataMat)
      }else{
        this.matriculat=false;
        console.log('Matriculat',dataMat)
        
      }
            this.activitatService.getAfPerActivitat(this.codiAct).subscribe(data =>{   
            
              xml2js.parseString(data, function (err,  result) {
                d=result['env:Envelope']['env:Body'][0]['ns0:findAccioformativasPerAcivitatResponse'][0]['ns2:result'];            
              })
              d=this.renameJson(d);
             
              console.log('detail',d);
              this.results=d

                            //agrupar
                            agrupa= d.reduce(function (r, a) {
                              console.log("reduce: ",typeof(a.TallerSim)[0])
                              if (typeof(a.TallerSim[0]) === 'string'){
                              r[a.TallerSim] = r[a.TallerSim] || [];
                              r[a.TallerSim].push(a);
                              }
                              return r;
                          }, Object.create(null));
          
              if (typeof (d[0]) !=='undefined'){
                console.log("definido")
                d[0].check=true
                this.nomActivitat=this.results[0]['Nom'][0]
              }
              else{
                console.log("Undefinido")
              }  

        console.log(agrupa[0]['0']['Aula']); 
        console.log('agrupa: ',Object.keys(agrupa))
        this.resultsAgrupats=Object.keys(agrupa)

            })   
     
    })
    
  }

  async matricula() {
    console.log("EntraMAtricula")
    var dd: JSON
    var trobat: boolean = false
    return this.activitatService.getLlistaInscripObertes().toPromise().then(data => {
      xml2js.parseString(data, function (err, result) {
        dd = result['env:Envelope']['env:Body'][0]['ns0:findActivitatView1ActivitatLlistaMatriculesResponse'][0]['ns2:result'];
      });
      dd = this.renameJson(dd);
      for (var index in dd) {
        console.log(dd[index]['Codi'] + " " + this.codiAct);
        if (this.codiAct == dd[index]['Codi']) {
          trobat = true;
          break;
        }
      }
      console.log("Trobat: ", trobat)
    
    }).then(r=>trobat)


  }

  async presentAlertVolsMatricularte() {
    const alert = await this.alertController.create({
      header: 'Matrícula',
      message: '<strong>Vols confirmar la matrícula?</strong>!!!',
      buttons: [
        {text: 'Cancel',role: 'cancela',cssClass: 'secondary',
          handler: async (blah) => {

              await this.matricula().then(d=>{

                console.log("THISTROBAT", d)
                if (d===true){
                  console.log("ISTRUE")
                }else{console.log("ISFALSE")}
              })

          }},
           {
          text: 'Ok',
          handler: async () => {

            
            console.log('Results with chech: ', this.results[0].check)
            console.log('Results with chech: ', this.results[0].IdAf)

            await this.matricula().then(d=>{

              console.log("THISTROBAT", d)
              if (d===true){
                console.log("ISTRUE")

                this.MatricularActivitat(this.codiAct, this.dni)

                for (var val of this.results) {
                  console.log("check",val.check); 
                  if (val.check===true){
                    console.log("Matriculandose",this.codiAct + " " +localStorage.getItem("loginDni")+ " "+ val.IdAf)
                    this.MatricularAf(this.codiAct,localStorage.getItem("loginDni"),val.IdAf)
                  }
                }
                this.presentAlertaMatriculat()


              }else{
                console.log("ISFALSE")
                this.presentAlertaCancelarMatricula()}

            });

          }
        }
      ]
    });

    await alert.present();
  }
   async MatricularActivitat(codiAct: any, Dni: string){

    this.activitatService.matriculaActivitat(codiAct, Dni).subscribe(data => {
       console.log("MatriculaActivitat", data);
     }) 
    
  }

  async MatricularAf(codiAct: any, Dni: string, IdAf: any){
    this.activitatService.createAf(IdAf,codiAct,Dni).subscribe(data =>{
      console.log("createAf",data)
  })
  }

  async presentAlertaMatriculat(){
    const alertMatriculat = await this.alertController.create({
      header: 'Inscripció',
      message: '<strong>T\'has matriculat de '+ this.results[0].Nom+ '</strong>!!!',
      buttons:[
        {
          text: 'Ok',
        handler: ()=>{
          this.alertCrearEventoCalendar()
          this.router.navigateByUrl('/activitats/'+localStorage.getItem("loginDni"))
        }
        }
      ]
    });
    alertMatriculat.present();
  }

  async presentAlertaCancelarMatricula(){
    const alertCancelaMatricula = await this.alertController.create({
      header: 'Inscripció',
      message: '<strong>Ho sentim però ja no queden places a l\'activitat '+ this.results[0].Nom+ '</strong>!!!',
      buttons:[
        {
          text: 'Ok',
        handler: ()=>{
          //this.router.navigateByUrl('/activitats/'+localStorage.getItem("loginDni"))
        }
        }
      ]
    });
    alertCancelaMatricula.present();

  }
  

    async alertCrearEventoCalendar(){

      const alertMatriculat=  await this.alertController.create({
        header: 'Calendari',
        message: "<strong>Vols afegir l\'activitat "+ this.results[0].Nom+ "al caldenari el dia "+this.results[0].DataInici+"?</strong>!!!",
        buttons:[
          {
            text: 'Ok',
          handler: ()=>{
              this.addEvent(this.calendars[0])
            this.router.navigateByUrl('/activitats/'+localStorage.getItem("loginDni"))
          }
        },
          {
            text: 'Cancel',
            role: 'cancela',
            cssClass: 'secondary',
            handler: (blah) => {
              console.log('Confirm Cancel: blah');
              this.router.navigateByUrl('/activitats/'+localStorage.getItem("loginDni"))
            }
          }
          
        ]
      });
      alertMatriculat.present();
    }

    addEvent(cal) {
      let dataInici = new Date(this.results[0].DataInici);
      let dataFi = new Date(this.results[0].DataFi)
      let date = new Date()
      let nom: string= this.results[0].Nom
      let ubicacio: string= this.results[0].Ubicacio
      let notas: string = this.results[0].Aula + '. '+ this.results[0].Calendari

              //TODO-> Mirar que haya algun calendario en la lista

      console.log(this.results[0].Nom + ' '+this.results[0].Ubicacio+'. '+ this.results[0].Aula+' ' +this.results[0].Calendari)
      let options = { calendarId: cal.id, calendarName: cal.name, url: 'http://www.ub.edu/sae/', firstReminderMinutes: 180 };
   
      this.calendar.createEventInteractivelyWithOptions(`${nom}`, `${ubicacio}`, `${notas}`, date, date, options).then(res => {
      }, err => {
        console.log('err: ', err);
      });
    }


  onClick(i,tallerSim) {
    

    for(var index in this.results){
      //console.log('antesbucle: ',tallerSim[0]['$'])
      
      if (this.results[index].TallerSim[0]==tallerSim[0]){
        if(i != index){this.results[index].isChecked=false}
        //this.results[index].isChecked=false
        //console.log(this.results[index].TallerSim)
      }
      console.log(this.results[index].check)
    }
    this.results[i].check=!this.results[i].check;

    console.log("click: ",this.results[i].check)
    console.log("idAf: ",this.results[i]['IdAf'][0])
    console.log ('i',i);
    console.log ('textcab',tallerSim[0]);
  }


  private renameJson(json) {  
    var str:string

    str = JSON.stringify(json); 
    str = str.replace(/ns1:/g,'');
    //console.log('outs',str); 
    json = JSON.parse(str);
    return json
   }
   
   ionRefresh(event) {
this.ngOnInit()
    setTimeout(() => {
      console.log('Async operation has ended');
      //complete()  signify that the refreshing has completed and to close the refresher
      event.target.complete();
    }, 2000);
}
}

