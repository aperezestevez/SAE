import { Component, OnInit } from '@angular/core';
import { Plugins,StatusBarStyle } from '@capacitor/core'
import { Platform } from '@ionic/angular';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { DarkmodeIos } from 'src/app/services/darkmode-ios.service.service';


@Component({
  selector: 'app-config-app',
  templateUrl: './config-app.page.html',
  styleUrls: ['./config-app.page.scss'],
})
export class ConfigAppPage implements OnInit {
  Dni: any;
  darkMode: boolean= (window.localStorage.getItem('darkmode')== 'true')
  constructor( private platform: Platform,
    private statusBar: StatusBar,
    private darkmodeIos: DarkmodeIos

    ) { 
    //const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
    //this.darkMode = prefersDark.matches;


  }

  ngOnInit() {
    this.Dni = localStorage.getItem('loginDni')
    console.log('DM: '+ window.localStorage.getItem('darkmode'))
    if ( typeof(window.localStorage.getItem('darkmode'))!=='undefined' ) {
      var darkmodelocal:boolean
      darkmodelocal =(window.localStorage.getItem('darkmode')== 'true')

      this.darkMode= darkmodelocal
    }else{
      this.darkMode= false

    }
  }
  cambioModo($event){
    // const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
    this.darkMode = !this.darkMode;
   

    window.localStorage.setItem('darkmode',String(this.darkMode))
    document.body.classList.toggle('dark', this.darkMode);
    console.log("DArkmode"+this.darkMode)

    if (this.platform.is("ios")){
      this.darkmodeIos.darkmodeIos(this.darkMode)

    }else{
      if (this.darkMode){
        this.statusBar.styleBlackOpaque()
        this.statusBar.backgroundColorByHexString("#000000")
      }
      else{
        this.statusBar.styleDefault()
        this.statusBar.backgroundColorByHexString("#FFFFFF")
      }


  }

  }

}
