import { Component, OnInit } from '@angular/core';
import { ActivitatService } from 'src/app/services/activitat.service';
import * as xml2js from 'xml2js';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import { ActivatedRoute } from '@angular/router';
import { InAppBrowser, InAppBrowserOptions } from '@ionic-native/in-app-browser/ngx';
import { OneSignal } from "@ionic-native/onesignal/ngx";
import { Platform, AlertController } from '@ionic/angular';
import { SafariViewController } from '@ionic-native/safari-view-controller/ngx';
import { NavController } from '@ionic/angular';



@Component({
  selector: 'app-activitats',
  templateUrl: './activitats.page.html',
  styleUrls: ['./activitats.page.scss'],
})
export class ActivitatsPage implements OnInit {

  results:any;
  result:any;
  searchTerm: string = '';
  dni:any;
  matObertes:any;
 

  darkmode =(window.localStorage.getItem('darkmode')== 'true');
  constructor(private activitatService: ActivitatService,private activatedRoute: ActivatedRoute,private iab: InAppBrowser,
    private oneSignal: OneSignal,private alertCtrl: AlertController,private platform: Platform,
    private safariViewController: SafariViewController, private navCtrl: NavController,
    ) { }

  ngOnInit() {
    this.dni=this.activatedRoute.snapshot.paramMap.get('dni');
    localStorage.setItem("loginDni", this.dni)
    var d:JSON
    var dd:JSON
    var str:string

    if (this.platform.is('cordova')) {
      this.setupPush(localStorage.getItem('loginDni'));
    }
    this.activitatService.searchData(this.dni).subscribe(data => {   
      xml2js.parseString(data, function (err,  result:string) {
        //console.log('resultyo',result);    
        d=result['env:Envelope']['env:Body'][0]['ns0:findPersonesActivitatView1PersonesActivitatViewCriteriaResponse'][0]['ns2:result'];
        console.log('dyo',d);
      })   
      d=this.renameJson(d);   
      console.log('out',d);
      this.results=d 
          this.activitatService.getLlistaInscripObertes().subscribe(data =>{      
            xml2js.parseString(data, function (err,  result) {
              dd=result['env:Envelope']['env:Body'][0]['ns0:findActivitatView1ActivitatLlistaMatriculesResponse'][0]['ns2:result'];
            })
            dd=this.renameJson(dd);
            //this.results=d   
            this.matObertes= Object.keys(dd).length
          })


    },error =>{
      console.log("error en search data: ", error);
    });

 

  }

  searchChanged(){
    let dni = this.activatedRoute.snapshot.paramMap.get('dni');
    var d:JSON
    var str:string
    this.activitatService.activitatFilter(this.searchTerm,dni).subscribe(data => {
      
      xml2js.parseString(data, function (err,  result:string) {
      
        console.log('resultyo',result); 
        
        d=result['env:Envelope']['env:Body'][0]['ns0:findPersonesActivitatView1PersonesActivitatSearchResponse'][0]['ns2:result'];
        //console.log('dyo',d);
      })
     
      if (typeof (d) ==='undefined'){}else{
        d=this.renameJson(d);
      }
      
     
      console.log('out',d);
      this.results=d
    },error =>{
      console.log("error en search data: ", error);
    })

    this.newMethod();
  }

  private newMethod() {
  
    console.log("HOLA2")
  }

  private renameJson(json) {  
    var str:string

    str = JSON.stringify(json); 

    str = str.replace(/ns1:/g,'');
    console.log('outs',str); 
    json = JSON.parse(str);
    return json
   }

   launch(Codi) {
    const browser = this.iab.create('http://www.ub.edu/gicepre-mat/printinforme?NomInforme=SortidaMatricula&Dni='+this.dni+'&Tipus=Pdf&Codi='+Codi+'&Sortida=okgr&llengua=ca&entitat=SAE','_system');
    console.log("browser",browser)
    
   }

   logout(){
     console.log('me las piro')
     this.safariViewController.isAvailable()
     .then((available: boolean) => {
         if (available) {
   
           this.safariViewController.show({
             url: 'https://sso.ub.edu/UB/LOGOUT',
             hidden: false,
             animated: false,
             transition: 'curl'
           })
           .subscribe((result: any) => {
               if(result.event === 'opened') console.log('Opened');
               else if(result.event === 'loaded') {
                 console.log('Loaded and location: '+window.location);}
               else if(result.event === 'closed'){ 
                 console.log('Closed');
                 const nav =  this.navCtrl.navigateRoot('/');  
                 }
 
             },
             (error: any) => console.error(error)
           );
   
         } else {
           // use fallback browser, example InAppBrowser
         }
       }
     );
   }

    setupPush(dni: string) {
      this.oneSignal.startInit('46047ffc-fbbd-4a9f-8a8b-11da176db27e', '662982765918')

      this.oneSignal.inFocusDisplaying(this.oneSignal.OSInFocusDisplayOption.InAppAlert)
      this.oneSignal.setExternalUserId(dni)
      this.oneSignal.sendTag('ID','23456')
      

      this.oneSignal.handleNotificationReceived().subscribe(data => {
        let msg = data.payload.body;
        let title = data.payload.title;
        let additionalData = data.payload.additionalData;
        this.showAlert(title, msg, additionalData.task)

      });

      this.oneSignal.handleNotificationOpened().subscribe(data => {

        let additionalData = data.notification.payload.additionalData;
        this.showAlert('Notificacio oberta','Llegida',additionalData.task);

      });



      this.oneSignal.endInit()
    }
    async showAlert(title: string, msg: string, task: any) {
      const alert = await this.alertCtrl.create({
        header: title,
        subHeader: msg,
        buttons: [
          {
            text: `Acció: ${task}`,
            handler: ()=>{
              //ej: Navigate to specific screen
            }
          }
        ]
      })
      alert.present();
    }
    doRefresh(event) {
      this.ngOnInit()
      setTimeout(() => {
        console.log('Async operation has ended');
        //complete()  signify that the refreshing has completed and to close the refresher
        event.target.complete();
      }, 2000);
    }


}
