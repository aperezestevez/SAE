import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ActivitatsPage } from './activitats.page';

const routes: Routes = [
  {
    path: '',
    component: ActivitatsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ActivitatsPageRoutingModule {}
