import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { EnquestaPageRoutingModule } from './enquesta-routing.module';

import { EnquestaPage } from './enquesta.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    EnquestaPageRoutingModule
  ],
  declarations: [EnquestaPage]
})
export class EnquestaPageModule {}
