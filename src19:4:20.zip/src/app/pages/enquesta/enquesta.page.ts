import { Component, OnInit,Input, EventEmitter ,Output } from '@angular/core';
import { ModalController, AlertController,ToastController } from '@ionic/angular';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-enquesta',
  templateUrl: './enquesta.page.html',
  styleUrls: ['./enquesta.page.scss'],
})
export class EnquestaPage implements OnInit {

  @Input() rating: number=0 ;

  @Output() ratingChange: EventEmitter<number> = new EventEmitter();;
  opinio:any
  nomAf:any
  codiAf:string
  constructor(private modalCtrl:ModalController,private activatedRoute: ActivatedRoute, 
    private alertController: AlertController,
    private toastController: ToastController
    ) { }

  ngOnInit() {
  }
  dismissModal(){
    this.modalCtrl.dismiss({
      'dismissed': true
    });
  }

  rate(index: number){
    console.log(index)
    this.rating=index
    this.ratingChange.emit(this.rating)
  }
  getColor(index: number) {
    if (this.isAboveRating(index)){
      return 'grey'
    }
    switch(index){
      case 1: return '#fb9407';
      case 2: return '#fb9407';
      case 3: return '#fb9407';
      case 4: return '#fb9407';
      case 5: return '#fb9407';
      default: return 'grey'

    }
  }
  isAboveRating(index: number): boolean {
    // returns whether or not the selected index is above ,the current rating
    // function is called from the getColor function.
    return index > this.rating
  }
  guardarEnquesta(){

    console.log("Index ",this.rating)
    console.log('input', this.opinio)
    console.log('dni ', localStorage.getItem('loginDni'))
    console.log('idAf ', this.codiAf[0])

    if (typeof (this.opinio)==='undefined'){
      this.presentAlert()

    }else{
      this.presentToast()
    this.dismissModal()
    }
  }

  async presentAlert() {
    const alert = await this.alertController.create({
      header: 'Valoració',
      message: 'Si us plau escriu una valoració, gracies!!.',
      buttons: ['OK']
    });
    await alert.present();
  }

  async presentToast() {
    const toast = await this.toastController.create({
      message: 'Gracies per la teva valoració.',
      duration: 2000,
      position: 'bottom',
      mode: 'ios'
    });
    toast.present();
  }
}
