import { TestBed } from '@angular/core/testing';

import { DarkmodeIos.ServiceService } from './darkmode-ios.service.service';

describe('DarkmodeIos.ServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DarkmodeIos.ServiceService = TestBed.get(DarkmodeIos.ServiceService);
    expect(service).toBeTruthy();
  });
});
