import { Injectable } from '@angular/core';
import { Plugins,StatusBarStyle } from '@capacitor/core'
import { Platform } from '@ionic/angular';


const { StatusBar } = Plugins;

@Injectable({
  providedIn: 'root'
})
export class DarkmodeIos {

  constructor() { }


darkmodeIos(darkmode){

  StatusBar.setStyle({
    style: darkmode ? StatusBarStyle.Dark : StatusBarStyle.Light
  });
}

}
