import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { ActivitatService } from './services/activitat.service';
import { HTTP } from '@ionic-native/http/ngx';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { Screenshot } from '@ionic-native/screenshot/ngx';
import { OCR, OCRSourceType, OCRResult } from '@ionic-native/ocr/ngx';
import { ViewChild, AfterViewInit } from '@angular/core';
import { Platform } from '@ionic/angular';
import {BrowserTab} from '@ionic-native/browser-tab/ngx'
import { SafariViewController } from '@ionic-native/safari-view-controller/ngx';
import { OneSignal } from '@ionic-native/onesignal/ngx';
import { Deeplinks } from '@ionic-native/deeplinks/ngx';
import { Calendar } from '@ionic-native/calendar/ngx';
import { NativePageTransitions } from '@ionic-native/native-page-transitions/ngx';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CacheModule} from 'ionic-cache';



@NgModule({
  declarations: [AppComponent],
  entryComponents: [],
  imports: [BrowserModule, IonicModule.forRoot(), AppRoutingModule,HttpClientModule],
  providers: [
    StatusBar,
    SplashScreen,
    HTTP,
    ActivitatService,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    InAppBrowser,
    Screenshot,
    OCR,
    ViewChild,
    Platform,
    BrowserTab,
    SafariViewController,
    OneSignal,
    Deeplinks,
    Calendar,
    NativePageTransitions,
    BrowserAnimationsModule


  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
