import { TestBed } from '@angular/core/testing';

import { ActivitatService } from './activitat.service';

describe('ActivitatService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ActivitatService = TestBed.get(ActivitatService);
    expect(service).toBeTruthy();
  });
});
