import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import * as xml2js from 'xml2js';


@Injectable({
  providedIn: 'root'
})
export class ActivitatService {



  //url='http://161.116.102.95:8006/wsice/AppModuleService';
  //url="http://www.ub.edu/wsidp/AppModuleService";
  //url= '/wsice/AppModuleService';
  url = 'http://www.ub.edu/wsidp/servletapp';
  urlAutenticacio = 'http://www.ub.edu/wsidp/autenticacio?'
  xmlItems: any;
  results: any;
  resul: any;
  CodiActivitat: String = "23750";
  DadesPersonaGlobal: any = 'Hola';

  body = "<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns1=\"/model/common/types/\" xmlns:ns2=\"http://xmlns.oracle.com/adf/svc/types/\">" +
    "<env:Header/>" +
    "<env:Body>" +
    "   <ns1:findPersonesActivitatView1PersonesActivitatViewCriteria>" +
    "      <ns1:DniInscripcio>46726763</ns1:DniInscripcio>" +
    "   </ns1:findPersonesActivitatView1PersonesActivitatViewCriteria>" +
    "</env:Body>" +
    "</env:Envelope>";



  constructor(private http: HttpClient) { }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'text/xml',
      'Access-Control-Allow-Origin': '*',
      'responseType': 'text',
      'Accept': 'text/xml'
    })
  };
  headers = new HttpHeaders()


  searchData(dni: string) {
    console.log("dni: ", dni)
    return this.http.post(this.url + "?dni=" + dni + "&accio=PersonesActivitat", "", { headers: this.headers, responseType: 'text' })

  }
  getDetails(id: string, dni: string) {

    var bodyAF = "<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns1=\"/model/common/types/\" xmlns:ns2=\"http://xmlns.oracle.com/adf/svc/types/\">" +
      "<env:Header/>" +
      "<env:Body>" +
      "   <ns1:findPersonesAccioformativaView1>" +
      "      <ns1:DniAlumne>46726763</ns1:DniAlumne>" +
      "         <ns1:CodiAct>" + id + "</ns1:CodiAct>" +
      "   </ns1:findPersonesAccioformativaView1>" +
      "</env:Body>" +
      "</env:Envelope>";


    console.log('CodiActi ', id);
    return this.http.post(this.url + "?dni=" + dni + "&codiact=" + id + "&accio=PersonesAF", "", { headers: this.headers, responseType: 'text' })
  }

  getDadesPersonals(dni: string) {

    return this.http.post(this.url + "?dni=" + dni + "&accio=Persones", "", { headers: this.headers, responseType: 'text' })


  }

  getToken(dni: string) {

    return this.http.post(this.url + "?dni=" + dni + "&accio=Persones", "", { headers: this.headers, responseType: 'text' }).toPromise()
    
    }

  getDadesGiga(dni: string) {
    return this.http.post(this.url + "?dni=" + dni + "&accio=Giga", "", { headers: this.headers })

  }

  activitatFilter(searchTerm: string, dni: string) {

    return this.http.post(this.url + "?dni=" + dni + "&contingutActivitat=" + searchTerm + "&accio=PersonesActivitatSearch", "", { headers: this.headers, responseType: 'text' })

  }
  getLlistaInscripObertes() {
    return this.http.post(this.url + "?&accio=LlistaInscripcions", "", { headers: this.headers, responseType: 'text' })

  }

  getAfPerActivitat(codiAct) {

    return this.http.post(this.url + "?codiact=" + codiAct + "&accio=AfPerActivitat", "", { headers: this.headers, responseType: 'text' })

  }
  jaMatriculat(codiAct: string, dni: string) {
    return this.http.post(this.url + "?dni=" + dni + "&codiact=" + codiAct + "&accio=JaMatriculat", "", { headers: this.headers, responseType: 'text' })
  }
  matriculaActivitat(codiAct: string, dni: string) {

    return this.http.post(this.url + "?dni=" + dni + "&codiact=" + codiAct + "&accio=MatriculaActivitat", "", { headers: this.headers, responseType: 'text' })

  }
  createAf(codiAf: string, codiAct: string, dni: string) {
    return this.http.post(this.url + "?dni=" + dni + "&codiact=" + codiAct + "&codiAf=" + codiAf + "&accio=CreateAf", "", { headers: this.headers, responseType: 'text' })
  }
  auten() {
    return this.http.post("http://www.ub.edu/wsidp/servletapp?accio=Auten", "", { headers: this.headers, responseType: 'text' })

  }

}
