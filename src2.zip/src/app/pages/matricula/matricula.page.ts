import { Component, OnInit } from '@angular/core';
import { ActivatedRoute , Router} from '@angular/router';
import { ActivitatService } from 'src/app/services/activitat.service';
import * as xml2js from 'xml2js';
import { AlertController, Platform } from '@ionic/angular';
import { Calendar } from '@ionic-native/calendar/ngx';

@Component({
  selector: 'app-matricula',
  templateUrl: './matricula.page.html',
  styleUrls: ['./matricula.page.scss'],
})
export class MatriculaPage implements OnInit {
  results:any;
  codiAct:any;
  matriculat:any;
  resultsMatricula:any;
  nomActivitat:any;
  dni:any;
  calendars = [];
  constructor(private router: Router , private activitatService: ActivitatService,private activatedRoute: ActivatedRoute,
    public alertController: AlertController, private calendar: Calendar, private platform: Platform) { 

      this.platform.ready().then(() => {
        this.calendar.requestReadWritePermission();
        this.calendar.hasWritePermission().then(permission =>{
          console.log("PERMISION: "+ permission)
              this.calendar.listCalendars().then(data => {
                this.calendars = data;
                  console.log('constructorCal'+data)
              })
              .catch(err => {console.log('errorCalConstru: '+ err)});

        });

        
      });
    }

  ngOnInit() {
    var d = 10;
    this.dni=localStorage.getItem("loginDni")
    console.log("Dni: ", this.dni);
    this.codiAct = this.activatedRoute.snapshot.paramMap.get('codiAct');
    console.log("Codi: ", this.codiAct);

    this.activitatService.jaMatriculat(this.codiAct,localStorage.getItem("loginDni")).subscribe(dataMat =>{   
      console.log('datamat',dataMat)
      if (dataMat==='true'){
        this.matriculat=true;
        console.log('Matriculat',dataMat)
      }else{
        this.matriculat=false;
        console.log('Matriculat',dataMat)
        
      }
            this.activitatService.getAfPerActivitat(this.codiAct).subscribe(data =>{   
            
              xml2js.parseString(data, function (err,  result) {
                d=result['env:Envelope']['env:Body'][0]['ns0:findAccioformativasPerAcivitatResponse'][0]['ns2:result'];
              })
              d=this.renameJson(d);
             
              console.log('detail',d);
              this.results=d
              
              if (typeof (d[0]) !=='undefined'){
                console.log("definido")
                d[0].check=true
                this.nomActivitat=this.results[0]['Nom'][0]
              }
              else{
                console.log("Undefinido")
              }   
            })   
     
    })
    
  }

  async presentAlert() {
    const alert = await this.alertController.create({
      header: 'Matrícula',
      message: '<strong>Vols confirmar la matrícula?</strong>!!!',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancela',
          cssClass: 'secondary',
          handler: (blah) => {
            console.log('Confirm Cancel: blah');
          }
        }, {
          text: 'Ok',
          handler: async () => {
            
            console.log('Results with chech: ', this.results[0].check)
            console.log('Results with chech: ', this.results[0].IdAf)

             this.MatricularActivitat(this.codiAct, this.dni)

            for (var val of this.results) {
              console.log("check",val.check); 
              if (val.check===true){
                console.log("Matriculandose",this.codiAct + " " +localStorage.getItem("loginDni")+ " "+ val.IdAf)
                this.MatricularAf(this.codiAct,localStorage.getItem("loginDni"),val.IdAf)
            }

            }

            this.presentAlertaMatriculat()
          }
        }
      ]
    });

    await alert.present();
  }
   async MatricularActivitat(codiAct: any, Dni: string){

    this.activitatService.matriculaActivitat(codiAct, Dni).subscribe(data => {
       console.log("MatriculaActivitat", data);
     }) 
    
  }

  async MatricularAf(codiAct: any, Dni: string, IdAf: any){
    this.activitatService.createAf(IdAf,codiAct,Dni).subscribe(data =>{
      console.log("createAf",data)
  })
  }

   async presentAlertaMatriculat(){
    const alertMatriculat=  await this.alertController.create({
      header: 'Inscripció',
      message: '<strong>T\'has matriculat de '+ this.results[0].Nom+ '</strong>!!!',
      buttons:[
        {
          text: 'Ok',
        handler: ()=>{
          this.alertCrearEventoCalendar()
          //this.router.navigateByUrl('/activitats/'+localStorage.getItem("loginDni"))
        }
        }
      ]
    });
    alertMatriculat.present();
  }

    async alertCrearEventoCalendar(){

      const alertMatriculat=  await this.alertController.create({
        header: 'Calendari',
        message: "<strong>Vols afegir l\'activitat "+ this.results[0].Nom+ "al caldenari el dia "+this.results[0].DataInici+"?</strong>!!!",
        buttons:[
          {
            text: 'Ok',
          handler: ()=>{
              this.addEvent(this.calendars[0])
            this.router.navigateByUrl('/activitats/'+localStorage.getItem("loginDni"))
          }
        },
          {
            text: 'Cancel',
            role: 'cancela',
            cssClass: 'secondary',
            handler: (blah) => {
              console.log('Confirm Cancel: blah');
              this.router.navigateByUrl('/activitats/'+localStorage.getItem("loginDni"))
            }
          }
          
        ]
      });
      alertMatriculat.present();
    }

    addEvent(cal) {
      let dataInici = new Date(this.results[0].DataInici);
      let dataFi = new Date(this.results[0].DataFi)
      let date = new Date()
      let nom: string= this.results[0].Nom
      let ubicacio: string= this.results[0].Ubicacio
      let notas: string = this.results[0].Aula + '. '+ this.results[0].Calendari

              //TODO-> Mirar que haya algun calendario en la lista

      console.log(this.results[0].Nom + ' '+this.results[0].Ubicacio+'. '+ this.results[0].Aula+' ' +this.results[0].Calendari)
      let options = { calendarId: cal.id, calendarName: cal.name, url: 'http://www.ub.edu/sae/', firstReminderMinutes: 180 };
   
      this.calendar.createEventInteractivelyWithOptions(`${nom}`, `${ubicacio}`, `${notas}`, date, date, options).then(res => {
      }, err => {
        console.log('err: ', err);
      });
    }


  onClick(i) {
    this.results[i].check=!this.results[i].check;
    console.log("click: ",this.results[i].check)
    console.log("idAf: ",this.results[i]['IdAf'][0])
    console.log ('i',i);
  }


  private renameJson(json) {  
    var str:string

    str = JSON.stringify(json); 
    str = str.replace(/ns1:/g,'');
    console.log('outs',str); 
    json = JSON.parse(str);
    return json
   }
   
   ionRefresh(event) {
    var d = 10;
    console.log('Pull Event Triggered!');
    this.activitatService.getAfPerActivitat(this.codiAct).subscribe(data =>{   
            
      xml2js.parseString(data, function (err,  result) {
        d=result['env:Envelope']['env:Body'][0]['ns0:findAccioformativasPerAcivitatResponse'][0]['ns2:result'];
      })
      d=this.renameJson(d);
     
      console.log('detail',d);
      this.results=d
      if (typeof (d[0]) !=='undefined'){d[0].check=true}   //AF0
    })
    setTimeout(() => {
      console.log('Async operation has ended');
      //complete()  signify that the refreshing has completed and to close the refresher
      event.target.complete();
    }, 2000);
}
}

