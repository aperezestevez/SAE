import { Component, OnInit ,NgZone, ComponentFactoryResolver} from '@angular/core';
import { ActivitatService } from 'src/app/services/activitat.service';
import { NgForm } from '@angular/forms';
import * as xml2js from 'xml2js';
import { NavController } from '@ionic/angular';
//import { InAppBrowser,InAppBrowserOptions } from '@ionic-native/in-app-browser/ngx';
import { Plugins } from '@capacitor/core'
import { ViewChild, AfterViewInit, ElementRef } from '@angular/core';
import { IonSlides } from '@ionic/angular';
import { Screenshot } from '@ionic-native/screenshot/ngx';
import { OCR, OCRSourceType, OCRResult } from '@ionic-native/ocr/ngx';
import { Platform } from '@ionic/angular';
//import '@teamhive/capacitor-single-signon'
//import {BrowserTab} from '@ionic-native/browser-tab/ngx'
import { SafariViewController } from '@ionic-native/safari-view-controller/ngx';
//import { Deeplinks } from '@ionic-native/deeplinks/ngx';
import { NativePageTransitions, NativeTransitionOptions } from '@ionic-native/native-page-transitions/ngx';

const { Browser } = Plugins;
//const { SingleSignOn } = Plugins;
@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  @ViewChild('dni', { static: true }) slider: any;
  Dni: any;
  screen: any;
  screenTimeout: any;
  state: boolean = false;
  darkmode =(window.localStorage.getItem('darkmode')== 'true');
  DadesPersonaGlobal:any
  results:any

  constructor(private activitatService: ActivitatService, private navCtrl: NavController,private safariViewController: SafariViewController, private screenshot: Screenshot, private ocr: OCR,private platform: Platform) {
      
  }

  ngOnInit() {
    console.log("Plataforma")
    console.log(this.platform.platforms())
    console.log(this.platform.is("android"))
    console.log(this.platform.is("ios"))
    console.log("Plataforma")

  }
   

   login(form: NgForm) {
    this.Dni = form.value.Dni;
    var Password = form.value.Password;
    var d: JSON
    var str: string
    var token: string
    var dadesPersona: any
    

    console.log("form", this.Dni);
    localStorage.setItem("loginDni", this.Dni)

    const nav =  this.navCtrl.navigateRoot('/activitats/'+this.Dni);

    //this.controlDeeplinls()

    /*setTimeout(() => {
      console.log('DadesPersonaGlobalout ', d);
    }, 2000);*/
    
    //console.log('roken',token)
    //console.log("form",Password);
    //this.activitatService.getDadesPersonals(this.Dni).subscribe(data =>{   

    //xml2js.parseString(data, function (err,  result) {

    //console.log('resultyo',result); 
    //d=result['env:Envelope']['env:Body'][0]['ns0:getPersonesView1Response'][0]['ns2:result'][0];
    //console.log('dyo',d);
    //})
    // d=this.renameJson(d);

    //console.log('Password',d['Password'][0]);
    //this.results=d
    //console.log('details ', data);    


    //})
    //this.auten()
    //this.openBrowser()
  }
  safariVC(){
   
    this.safariViewController.isAvailable()
    .then((available: boolean) => {
        if (available) {
  
          this.safariViewController.show({
            url: 'http://www.ub.edu/wsidp/autenticacio?accio=Auten',
            hidden: false,
            animated: false,
            transition: 'curl',
            enterReaderModeIfAvailable: false,
            tintColor: '#ff0000'
          })
          .subscribe((result: any) => {
              if(result.event === 'opened') console.log('Opened');
              else if(result.event === 'loaded') {
                console.log('Loaded and location: '+window.location);}
              else if(result.event === 'closed'){ 
                console.log('Closed');
                //console.log('safariVC:'+localStorage.getItem('urlHandle'))
                //var urlHandle =localStorage.getItem('urlHandle').replace('appsae:/','')
                //const nav =  this.navCtrl.navigateRoot(urlHandle);
                }

            },
            (error: any) => console.error(error)
          );
  
        } else {
          // use fallback browser, example InAppBrowser
        }
      }
    );
    
  }

  async inAppBrowser() {
    //const iabbb =this.iab.create('http://www.ub.edu/wsidp/servletapp?accio=Auten','_self',{location: 'yes'})
//iabbb.show()
    /*await this.screenshot.save('jpg', 80, 'autenIab').then(res => {
      this.screen = res.filePath;
      this.state = true;
    });
    console.log('scrreAuten', this.screen);*/

    /*setTimeout(() => {
      console.log('DentroTimeout');
      console.log('servletdniApp'+localStorage.getItem('servletdni'));
      this.screenshot.save('jpg', 80, 'autenIabAndroid').then(res => {
        this.screen = res.filePath;
        console.log(JSON.stringify(res.filePath));
        this.state = true;
        this.ocr.recText(OCRSourceType.NORMFILEURL, "file://" + this.screen)
          .then((res: OCRResult) => {
            console.log(JSON.stringify(res.words.wordtext));
            iabbb.on('loadstop').subscribe(event => {
              console.log('urlEvent '+event.url)
           });
            iabbb.close();
            console.log('URLHandleIappBro:'+localStorage.getItem('urlHandle'))

            //const nav = this.navCtrl.navigateRoot('/activitats/'+localStorage.getItem('servletdni'));
          })
          .catch((error: any) => console.error(error));
      });
    }, 40000)*/

    
  }
  openBrowser() {
    var urlA = 'http://www.ub.edu/wsidp/servletapp?accio=Auten';

    // On iOS, for example, this will open the URL in Safari instead of 
    // the SFSafariViewController (in-app browser)
    Browser.open({ url: urlA });

    /*await this.screenshot.save('jpg', 80, 'Browser').then(res => {
      this.screen = res.filePath;
      this.state = true;
      this.ocr.recText(OCRSourceType.NORMFILEURL, "file://" + this.screen)
      .then((res: OCRResult) => console.log(JSON.stringify(res.words.wordtext)))
      .catch((error: any) => console.error(error))
    });*/

    setTimeout(() => {
      console.log('servletdniApp',localStorage.getItem('servletdni'))
      this.screenshot.save('jpg', 80, 'scrreOpenBrowserTimeout').then(res => {
        this.screenTimeout = res.filePath;
        console.log("res.filePath", res.filePath)
        this.state = true;

        console.log("screenTimeout", this.screenTimeout)
        this.ocr.recText(OCRSourceType.NORMFILEURL, "file://" + this.screenTimeout).then((resOcr: OCRResult) => {
            console.log('scrreOpenBrowser', this.screenTimeout);
            //const el: HTMLElement = document.getElementById('dni');
            //const dniText = el.innerText;
            //console.log("el El", document.getElementById('dni').innerText);
            console.log(JSON.stringify('Lines: '+resOcr.lines.linetext));
            console.log(JSON.stringify(resOcr.words.wordtext).split(','));
            //const nav =  this.navCtrl.navigateRoot('/activitats/'+this.Dni);         

          })
          //.catch((error: any) => console.error(error));
           /* Browser.close().then(res =>{
              console.log('URLHandleBInisdePromise:'+localStorage.getItem('urlHandle'))
              console.log('closeres: '+res)

            })
            .catch((error: any) => {console.error('BrowserClose'+error)})*/

            

          console.log('URLHandleB:'+localStorage.getItem('urlHandle'))

          //const nav =  this.navCtrl.navigateRoot('/activitats/46726763');
      });

    }, 30000);

  }

  openBrowserTab(){
    var vardatBT
    /*this.browserTab.isAvailable().then(isAvailable =>{
      if (isAvailable){
        this.browserTab.openUrl("http://www.ub.edu/wsidp/servletapp?accio=Auten").then( datBT=>{
            setTimeout(() => {
              vardatBT=datBT
              console.log('servletdniApp',localStorage.getItem('servletdni'))
              console.log('datBT'+datBT)
              console.log('Loaded and location: '+window.location)

            },30000)
        })
        setTimeout(() => {
          console.log('servletdniAppOUT',localStorage.getItem('servletdni'))
          console.log('datBTOUT'+vardatBT)
          console.log('URLHandleBT:'+localStorage.getItem('urlHandle'))
          this.browserTab.close().then(clo =>{
            console.log('URLHandleBTCloseBrowseerTab:'+localStorage.getItem('urlHandle'))

          })
        },30000) 
      }else{console.log('NoAvaliable')}

    })*/
  }
  renameJson(json) {
    var str: string

    str = JSON.stringify(json);
    str = str.replace(/ns1:/g, '');
    //console.log('renameJson', str);
    json = JSON.parse(str);
    return json
  }


  async safariVCIOS(){

    this.safariViewController.isAvailable()
    .then((available: boolean) => {
        if (available) {
  
          this.safariViewController.show({
            url: 'http://www.ub.edu/wsidp/servletapp?accio=Auten',
            hidden: true,
            animated: false
          })
          .subscribe((result: any) => {
            if(result.event === 'opened') {
              console.log('Opened');
              console.log('Loaded and location: '+window.location);
              console.log('safariVC:'+localStorage.getItem('urlHandle'))



              var urlHandle =localStorage.getItem('urlHandle').replace('appsae:/','')
              const nav =  this.navCtrl.navigateRoot(urlHandle);
            }
            else if(result.event === 'loaded') {
              console.log('Loaded and location: '+window.location);
              console.log('safariVC:'+localStorage.getItem('urlHandle'))
              var urlHandle =localStorage.getItem('urlHandle').replace('appsae:/','')
              const nav =  this.navCtrl.navigateRoot(urlHandle);
            }   
            else if(result.event === 'closed'){ 
              console.log('Closed');
              console.log('safariVC:'+localStorage.getItem('urlHandle'))
              var urlHandle =localStorage.getItem('urlHandle').replace('appsae:/','')
              const nav =  this.navCtrl.navigateRoot(urlHandle);
              }

           
          },
          (error: any) => console.error(error)
        );
  
        } else {
          // use fallback browser, example InAppBrowser
        }
        
      }
    );

  }

}

/*Browser.addListener('browserFinished', (info: any) => {

  console.log('browserFinished', info);
  this.screenshot.save('jpg', 80, 'browserFinished').then(res => {
    this.screen = res.filePath;
    this.state = true;
    this.ocr.recText(OCRSourceType.NORMFILEURL, "file://" + this.screen)
    .then((res: OCRResult) => {
      console.log(JSON.stringify('LinesBrowserFinish'+res.words.wordtext))
      console.log('URLHandleIBrowserFinish:'+localStorage.getItem('urlHandle'))
      var urlHandle =localStorage.getItem('urlHandle').replace('appsae:/','')


      const nav =  this.navCtrl.navigateForward(urlHandle);
    })
    .catch((error: any) => console.error(error))

  });

  console.log('Browser all done!');

});
Browser.addListener('browserPageLoaded', (info: any) => {
  console.log('Browser page loaded!');
  // Take a screenshot and get temporary file URI
  this.screenshot.save('jpg', 80, 'browserPageLoaded').then(res => {
    this.screen = res.filePath;
    this.state = true;
  });
  this.ocr.recText(OCRSourceType.NORMFILEURL, "file://" + this.screen)
    .then((res: OCRResult) => console.log(JSON.stringify(res.words.wordtext)))
    .catch((error: any) => console.error(error))
  console.log('scrreAddListener', this.screen);

  //console.log ('el El',document.getElementById('dni').innerText);
  console.log('browserPageLoadedinfo: '+typeof(info));
});
Browser.prefetch({
  urls: ["http://www.ub.edu/wsidp/servletapp?accio=Auten"]
});*/