import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { ActivitatService } from 'src/app/services/activitat.service';
import { connectableObservableDescriptor } from 'rxjs/internal/observable/ConnectableObservable';
import * as xml2js from 'xml2js';

@Component({
  selector: 'app-activitats-detail',
  templateUrl: './activitats-detail.page.html',
  styleUrls: ['./activitats-detail.page.scss'],
})
export class ActivitatsDetailPage implements OnInit {
  results:any;
  dni:any;

  constructor(private activatedRoute: ActivatedRoute, private activitatService: ActivitatService) { 

  }

  ngOnInit() {
    var d = 10;
    let id = this.activatedRoute.snapshot.paramMap.get('id');
    let dni = this.activatedRoute.snapshot.paramMap.get('dni');
    this.dni= dni;

    console.log('CodiAct ', id);

    this.activitatService.getDetails(id,dni).subscribe(data =>{   
      
      xml2js.parseString(data, function (err,  result) {
      
        //console.log('resultyo',result); 
        d=result['env:Envelope']['env:Body'][0]['ns0:findPersonesAccioformativaView1Response'][0]['ns2:result'];
        //console.log('dyo',d);
      })
      d=this.renameJson(d);
     
      console.log('detail',d);
      this.results=d
      //console.log('details ', data);    
    
    
    })

  }

  openWebsite(){
    window.open(this.results.Website, '_blank');
  }

  getCer(IdPerAf){}

  private renameJson(json) {  
    var str:string

    str = JSON.stringify(json); 
    str = str.replace(/ns1:/g,'');
    console.log('outs',str); 
    json = JSON.parse(str);
    return json
   }

}
