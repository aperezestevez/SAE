import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ActivitatService } from 'src/app/services/activitat.service';
import * as xml2js from 'xml2js';
import {Platform} from '@ionic/angular';
import { InAppBrowser, InAppBrowserOptions } from '@ionic-native/in-app-browser/ngx';
@Component({
  selector: 'app-llista-inscrip-obertes',
  templateUrl: './llista-inscrip-obertes.page.html',
  styleUrls: ['./llista-inscrip-obertes.page.scss'],
})
export class LlistaInscripObertesPage implements OnInit {
  results:any;
  constructor(private activatedRoute: ActivatedRoute, private activitatService: ActivitatService,private iab: InAppBrowser) { }

  ngOnInit() {
    var d = 10;
    this.activitatService.getLlistaInscripObertes().subscribe(data =>{   
      
      xml2js.parseString(data, function (err,  result) {
      
        //console.log('resultyo',result); 
        d=result['env:Envelope']['env:Body'][0]['ns0:findActivitatView1ActivitatLlistaMatriculesResponse'][0]['ns2:result'];
        //console.log('dyo',d);
      })
      d=this.renameJson(d);
     
      console.log('detail',d);
      this.results=d
      //console.log('details ', data);    
    
    
    })

  }

  toggleSection(i){
    this.results[i].open= !this.results[i].open;
    console.log('open: ',this.results[i].open+ ' i:'+ i)
  }


  launch(codiAct) {
    const browser = this.iab.create('http://www.ub.edu/gicepre/printinforme?NomInforme=ProgramaSae&Codi='+codiAct+'&Tipus=Pdf','_system');
    
}

  private renameJson(json) {  
    var str:string

    str = JSON.stringify(json); 
    str = str.replace(/ns1:/g,'');
    console.log('outs',str); 
    json = JSON.parse(str);
    return json
   }

}
