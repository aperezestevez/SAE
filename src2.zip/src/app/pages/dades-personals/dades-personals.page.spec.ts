import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { DadesPersonalsPage } from './dades-personals.page';

describe('DadesPersonalsPage', () => {
  let component: DadesPersonalsPage;
  let fixture: ComponentFixture<DadesPersonalsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DadesPersonalsPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(DadesPersonalsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
