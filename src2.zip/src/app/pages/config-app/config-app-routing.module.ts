import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ConfigAppPage } from './config-app.page';

const routes: Routes = [
  {
    path: '',
    component: ConfigAppPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ConfigAppPageRoutingModule {}
