import { Component, OnInit,Input, EventEmitter ,Output } from '@angular/core';
import { ModalController } from '@ionic/angular';


@Component({
  selector: 'app-enquesta',
  templateUrl: './enquesta.page.html',
  styleUrls: ['./enquesta.page.scss'],
})
export class EnquestaPage implements OnInit {
  @Input() rating: number=0 ;

  @Output() ratingChange: EventEmitter<number> = new EventEmitter();;

  constructor(private modalCtrl:ModalController) { }

  ngOnInit() {
  }
  dismissModal(){
    this.modalCtrl.dismiss({
      'dismissed': true
    });
  }

  rate(index: number){
    console.log(index)
    this.rating=index
    this.ratingChange.emit(this.rating)
  }
  getColor(index: number) {
    if (this.isAboveRating(index)){
      return 'grey'
    }
    switch(index){
      case 1: return 'red';
      case 2: return 'blue';
      case 3: return 'green';
      case 4: return 'green';
      case 5: return 'green';
      default: return 'grey'

    }
  }
  isAboveRating(index: number): boolean {
    // returns whether or not the selected index is above ,the current rating
    // function is called from the getColor function.
    return index > this.rating
  }
}
