import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { EnquestaPage } from './enquesta.page';

describe('EnquestaPage', () => {
  let component: EnquestaPage;
  let fixture: ComponentFixture<EnquestaPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnquestaPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(EnquestaPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
