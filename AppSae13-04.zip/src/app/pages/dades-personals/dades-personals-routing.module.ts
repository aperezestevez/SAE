import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DadesPersonalsPage } from './dades-personals.page';

const routes: Routes = [
  {
    path: '',
    component: DadesPersonalsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DadesPersonalsPageRoutingModule {}
