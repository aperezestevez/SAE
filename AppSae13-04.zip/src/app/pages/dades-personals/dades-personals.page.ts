import { Component, OnInit } from '@angular/core';
import { ActivitatService } from 'src/app/services/activitat.service';
import { ActivatedRoute } from '@angular/router';
import * as xml2js from 'xml2js';
@Component({
  selector: 'app-dades-personals',
  templateUrl: './dades-personals.page.html',
  styleUrls: ['./dades-personals.page.scss'],
})
export class DadesPersonalsPage implements OnInit {
  results:any;
  dadesGiga:any;
  ensenyaments:any;
  dni:any;
  foto:any;
  nomAlumne:any; niub:any; pais:any;adreca:any; naix:any; sexe:any;
  constructor(private activatedRoute: ActivatedRoute, private activitatService: ActivitatService) { }

  ngOnInit() {
    var d = 10;
    let dni = this.activatedRoute.snapshot.paramMap.get('dni');
    this.dni= dni;
    this.activitatService.getDadesPersonals(dni).subscribe(data =>{   
      
      console.log('adata ',data);
      xml2js.parseString(data, function (err,  result) {
      
        console.log('resultyo',result); 
        d=result['env:Envelope']['env:Body'][0]['ns0:getPersonesView1Response'][0]['ns2:result'];
        
        //console.log('dyo',d);
      })
      d=this.renameJson(d);
      //console.log('detail',d[0]['Foto']);
      if (typeof (d[0]['Foto']) ==='undefined'){
      }else{
        this.foto="data:image/jpeg;base64,"+d[0]['Foto'][0]
      }
        this.activitatService.getDadesGiga(dni).subscribe(data =>{
          console.log('GigaData ',data['response']);
          this.dadesGiga=data['response']
          this.ensenyaments=data['response']['ENSENYAMENT']
          this.nomAlumne = data['response']['NOM_ALUM'] + " "+ data['response']['COG1ALUM']+  " "+ data['response']['COG2ALUM']
          this.niub =data['response']['NIUB_ALUM']
          this.pais = "Pais naixement: "+data['response']['PAIS_NAIX'] + " Nacionalitat "+ data['response']['NACIONAL']
          this.adreca="Adreça: "+data['response']['ADREALUM']+ " " + data['response']['CODPOST']
          this.naix="Data naixement: "+data['response']['DATA_NAIX']
          this.sexe="Sexe: "+data['response']['SEXE']
        })

      this.results=d
      //console.log('details ', data);    

    })
    

    
    
  }
  private renameJson(json) {  
    var str:string

    str = JSON.stringify(json); 
    str = str.replace(/ns1:/g,'');
    console.log('outs',str); 
    json = JSON.parse(str);
    return json
   }
   ionRefresh(event) {
    console.log('Pull Event Triggered!');
    setTimeout(() => {
      console.log('Async operation has ended');

      //complete()  signify that the refreshing has completed and to close the refresher
      event.target.complete();
    }, 2000);
}

}
