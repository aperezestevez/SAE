import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ActivitatsDetailPage } from './activitats-detail.page';

const routes: Routes = [
  {
    path: '',
    component: ActivitatsDetailPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ActivitatsDetailPageRoutingModule {}
