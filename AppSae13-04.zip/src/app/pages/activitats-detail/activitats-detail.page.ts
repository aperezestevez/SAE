import { Component, OnInit} from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { ActivitatService } from 'src/app/services/activitat.service';
import { connectableObservableDescriptor } from 'rxjs/internal/observable/ConnectableObservable';
import * as xml2js from 'xml2js';
import { SafariViewController } from '@ionic-native/safari-view-controller/ngx';
import { AlertController, Platform } from '@ionic/angular';
import { ModalController } from '@ionic/angular';
import { EnquestaPage } from '../enquesta/enquesta.page';

@Component({
  selector: 'app-activitats-detail',
  templateUrl: './activitats-detail.page.html',
  styleUrls: ['./activitats-detail.page.scss'],
})
export class ActivitatsDetailPage implements OnInit {
  results:any;
  dni:any;

  constructor(private activatedRoute: ActivatedRoute, private activitatService: ActivitatService,
    private safariViewController: SafariViewController,
    private modalController: ModalController
    ) { 

  }

  ngOnInit() {
    var d = 10;
    let id = this.activatedRoute.snapshot.paramMap.get('id');
    let dni = this.activatedRoute.snapshot.paramMap.get('dni');
    this.dni= dni;
    

    console.log('CodiAct ', id);

    this.activitatService.getDetails(id,dni).subscribe(data =>{   
      
      xml2js.parseString(data, function (err,  result) {
      
        //console.log('resultyo',result); 
        d=result['env:Envelope']['env:Body'][0]['ns0:findPersonesAccioformativaView1Response'][0]['ns2:result'];
        //console.log('dyo',d);
      })
      d=this.renameJson(d);
     
      console.log('detail',d);
      this.results=d
      //console.log('details ', data);    
    
    
    })

  }

  openWebsite(){
    window.open(this.results.Website, '_blank');
  }
  


  async presentModal(CodiAf: string) {
    const modal = await this.modalController.create({
      component: EnquestaPage,
      swipeToClose: true,
      presentingElement: await this.modalController.getTop()
    });
    return await modal.present();
  }


  getCer(IdPerAf,CodiActivitat,Rol){
    var Nom: string = localStorage.getItem('Nom')
    var Cognom1: string = localStorage.getItem('Cognom1')
    var Cognom2: string = localStorage.getItem('Cognom2')
    

    this.safariViewController.isAvailable()
    .then((available: boolean) => {
        if (available) {
  
          this.safariViewController.show({
            url: 'http://www.ub.edu/gicepre/vistaprevia?Dni='+this.dni+'&Codi='+CodiActivitat+'&Signatura=signaturamaxturull.jpg&ImaCentral=&Zoom=2&IdAF=20466&Bilingue=N&ModMin=&Cos=Impartir&PdfDownload=Si&MostrarParticipants=N&CerManual=N&IdPerAf='+IdPerAf+'&Hores=&Rol='+Rol+'&Pdf=S',
            hidden: false,
            animated: true,
            transition: 'curl',
            enterReaderModeIfAvailable: false
          })
          .subscribe((result: any) => {
              if(result.event === 'opened') console.log('Opened');
              else if(result.event === 'loaded') {
                console.log('Loaded and location: '+window.location);}
              else if(result.event === 'closed'){ 
                console.log('Closed');
                }
            },
            (error: any) => console.error(error)
          );  
        } else {
          // use fallback browser, example InAppBrowser
        }
      }
    );

  }

  private renameJson(json) {  
    var str:string

    str = JSON.stringify(json); 
    str = str.replace(/ns1:/g,'');
    console.log('outs',str); 
    json = JSON.parse(str);
    return json
   }

}
