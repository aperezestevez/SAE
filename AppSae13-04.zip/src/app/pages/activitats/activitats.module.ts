import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ActivitatsPageRoutingModule } from './activitats-routing.module';

import { ActivitatsPage } from './activitats.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ActivitatsPageRoutingModule
  ],
  declarations: [ActivitatsPage]
})
export class ActivitatsPageModule {}
