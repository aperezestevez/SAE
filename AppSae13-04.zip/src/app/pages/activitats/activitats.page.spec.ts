import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { ActivitatsPage } from './activitats.page';

describe('ActivitatsPage', () => {
  let component: ActivitatsPage;
  let fixture: ComponentFixture<ActivitatsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivitatsPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ActivitatsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
