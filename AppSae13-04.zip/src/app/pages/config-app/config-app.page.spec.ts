import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { ConfigAppPage } from './config-app.page';

describe('ConfigAppPage', () => {
  let component: ConfigAppPage;
  let fixture: ComponentFixture<ConfigAppPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigAppPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ConfigAppPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
