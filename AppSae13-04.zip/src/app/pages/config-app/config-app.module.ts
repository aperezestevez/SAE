import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ConfigAppPageRoutingModule } from './config-app-routing.module';

import { ConfigAppPage } from './config-app.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ConfigAppPageRoutingModule
  ],
  declarations: [ConfigAppPage]
})
export class ConfigAppPageModule {}
