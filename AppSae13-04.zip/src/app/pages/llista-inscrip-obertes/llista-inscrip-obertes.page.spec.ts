import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { LlistaInscripObertesPage } from './llista-inscrip-obertes.page';

describe('LlistaInscripObertesPage', () => {
  let component: LlistaInscripObertesPage;
  let fixture: ComponentFixture<LlistaInscripObertesPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LlistaInscripObertesPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(LlistaInscripObertesPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
