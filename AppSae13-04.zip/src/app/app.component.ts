import { Component } from '@angular/core';
import * as xml2js from 'xml2js';
import { Platform,NavController } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Deeplinks } from '@ionic-native/deeplinks/ngx';
import { Router } from '@angular/router';
import { NgZone } from '@angular/core';
import { Plugins } from '@capacitor/core'
import { SafariViewController } from '@ionic-native/safari-view-controller/ngx';
import { ActivitatService } from './services/activitat.service';
import { Config, IonMenu, ModalController } from "@ionic/angular";

const { App } = Plugins;
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {
  DadesPersonaGlobal:any

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private deeplinks: Deeplinks,
    private router: Router,
    private zone: NgZone,
    private safariViewController: SafariViewController,
    protected navController: NavController,
    private activitatService: ActivitatService,
    
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
      this.checkDarkTheme();
      this.getUIDD();

      
      //this.setupDeeplinks();

      App.addListener('appUrlOpen', (data: any) => {
          App.getLaunchUrl().then(data =>{
            console.log('getlaunch '+data.url)
          })
        this.zone.run(() => {
            // Example url: https://beerswift.app/tabs/tab2
            // slug = /tabs/tab2
            console.log("url: "+data.url)
            console.log("iosOpenInPlace: "+data.iosOpenInPlace)
            console.log("iosSourceApplication: "+data.iosSourceApplication)
            this.controlDeeplinks(data.url)
            /*const appsaeRuta = data.url.split("appsae:/").pop();
            if (appsaeRuta) {
              console.log('urlto '+appsaeRuta)
                this.router.navigateByUrl(appsaeRuta)
                .then(safari =>{this.safariViewController.hide(); })
                .catch(err =>{console.log("routeerror: "+ err) });      
            }

             const slug = data.url.split(".com").pop();

            if (slug) {
              console.log('slug'+slug)
                this.router.navigateByUrl(slug)
                .then(safari =>{this.safariViewController.hide(); })
                .catch(err =>{
                  console.log("routeerror: "+ err)
                });
            }*/

        });
    });
    });

  }
  async controlDeeplinks(url:string){
    var urllink: string ='appsae://activitas/46726763/E3vES6dFVyY2GGwq358CjXSjRp3kpP4INwG03mLpAbzXoULko6ntU2Hb8TDeo15s'
    const urlSplit =url.split('/')
    console.log('urlSplit ', urlSplit)

    if (urlSplit[0] == 'appsae:'){
      this.safariViewController.hide(); 
      const a= await this.getToken(urlSplit[3])

      if (this.DadesPersonaGlobal[0]['Token'][0] =='undefined'){

        /*
        TODO--> REGISTRAR L'USUARI NOU, es alumne però no està registrar a la taula persones
        */

      }

      console.log ('uff ',this.DadesPersonaGlobal[0]['Token'][0])
      localStorage.setItem("Nom", this.DadesPersonaGlobal[0]['Nom'][0])
      localStorage.setItem("Cognom1", this.DadesPersonaGlobal[0]['Cognom1'][0])
      localStorage.setItem("Cognom2", this.DadesPersonaGlobal[0]['Cognom2'][0])

      console.log('dni ',urlSplit[3])
      console.log('token ',urlSplit[4])
      if (this.DadesPersonaGlobal[0]['Token'][0] == urlSplit[4]){
        console.log("SIIIIIIIII")
         if (urlSplit[2] == 'activitats'){
          this.router.navigateByUrl('/'+urlSplit[2]+'/'+urlSplit[3]).catch(err =>{console.log("routeerror: "+ err) }); 

         }else if (urlSplit[2] == 'matricula'){
          localStorage.setItem("loginDni", urlSplit[3])

          this.router.navigateByUrl('/'+urlSplit[2]+'/'+urlSplit[5]).catch(err =>{console.log("routeerror: "+ err) }); 

         }

      }
      else{/*TODO*/}
    } else if (urlSplit[0] == 'https:'){
      console.log('esHttps ',urlSplit)
      this.safariViewController.show({
        url: 'http://www.ub.edu/wsidp/autenticacio?accio=Matricula&codiact='+urlSplit[4],
        hidden: false,
        animated: false,
        transition: 'curl',
        enterReaderModeIfAvailable: false,
        tintColor: '#ff0000'
      }).subscribe((result: any) => {
        if(result.event === 'opened') console.log('Opened');
        else if(result.event === 'loaded') {
          console.log('Loaded and location: '+window.location);}
        else if(result.event === 'closed'){ 
          console.log('Closed');
          }
      },
      (error: any) => console.error(error)
    );


    }else{
      console.log('kk')
    }

   }

   async getToken(dni:string)
   {
     var d:any
       const a = await this.activitatService.getToken(dni)
      .then(data => {
        //console.log('adata ', data);
        xml2js.parseString(data, function (err, result) {
          //console.log('resultyo', result);
          d = result['env:Envelope']['env:Body'][0]['ns0:getPersonesView1Response'][0]['ns2:result'];
          //console.log('dyo',d);
        });
        d = this.renameJson(d);
        this.DadesPersonaGlobal = d;
        //console.log('details ', data);    
        console.log('DadesPersonaGlobal ', this.DadesPersonaGlobal);
      })
      

   }
   renameJson(json) {
    var str: string

    str = JSON.stringify(json);
    str = str.replace(/ns1:/g, '');
    //console.log('renameJson', str);
    json = JSON.parse(str);
    return json
  }
  checkDarkTheme() {
    //const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');

    if ( typeof(window.localStorage.getItem('darkmode'))!=='undefined' ) {
      var darkmode:boolean
      darkmode =(window.localStorage.getItem('darkmode')== 'true')

      document.body.classList.toggle( 'dark',  darkmode);
      
    }else{
      document.body.classList.toggle( 'dark',  false);
    }
  }
  setupDeeplinks() {
    console.log('Indeeplinks')
    this.deeplinks.route({ '/activitats/:dni': 'activitats' }).subscribe(
      match => {
        console.log('Successfully matched route', match);
 
        // Create our internal Router path by hand
        const internalPath = `/${match.$route}/${match.$args['dni']}`;
 
        // Run the navigation in the Angular zone
        this.zone.run(() => {
          this.router.navigateByUrl(internalPath);
        });
      },
      nomatch => {
        // nomatch.$link - the full link data
        console.error("Got a deeplink that didn't match", nomatch);
      }
    );
  }

  getUIDD(){

  /*this.uniqueDeviceID.get()
  .then((uuid: any) => console.log('UDID: '+uuid))
  .catch((error: any) => console.log(error));*/
  }

};


